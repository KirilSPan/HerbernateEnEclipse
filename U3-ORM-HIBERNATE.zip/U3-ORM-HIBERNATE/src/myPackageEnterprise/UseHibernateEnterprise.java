package myPackageEnterprise;

public class UseHibernateEnterprise {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		HibernateEnterprise h=new HibernateEnterprise();
		//h.addProduct(9, "monitor",170);
		//h.showProducts();
		
		//h.findProductById(1);
		//h.close();
		
		//h.updateProductById(1, "disco SSD", 50.45);
		h.addProduct(4, "teclado",39.99);
		h.showProducts();

	}

}
