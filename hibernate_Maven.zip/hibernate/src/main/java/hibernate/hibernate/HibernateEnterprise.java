package hibernate.hibernate;

import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.ObjectNotFoundException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;



public class HibernateEnterprise {

	private static SessionFactory sf; // this SessionFactory will be created once and used for all the connections

	HibernateEnterprise() {// constructor
		// sf = HibernateUtil.getSessionFactory();
		sf = new Configuration().configure().buildSessionFactory(); // also works
	}

	public void close() {
		sf.close();
	}

	@SuppressWarnings("deprecation")
	public void addProduct(int id, String name, double price) {
		Session session = sf.openSession();// session es l variable que tiene el método

		// save para guardar productos

		Transaction tx = null;
		// create the product with the parameters in the method
		Productos p = new Productos();
		p.setNombre(name);
		p.setPrecio(price);
		p.setId(id);
		// keep it in the database=session.save(p)
		try {
			System.out.printf("Inserting a row in the database: %s, %s, %s \n", id, name, price);

			tx = session.beginTransaction();
			session.save(p);// we INSERT p into the table PRODUCTS
			tx.commit();// if session.save doesn't produce an exception, we "commit" the transaction
		} catch (Exception e) {// if there is any exception, we "rollback" and close safely

			if (tx != null) {
				tx.rollback();
			}
		} finally {
			session.close();
		}
	}
	// class

	@SuppressWarnings("rawtypes")
	public void showProducts() {

		Session session = sf.openSession();
		Transaction tx = null;

		try {
			tx = session.beginTransaction();
			@SuppressWarnings("deprecation")
			List allproducts = session.createQuery("FROM Productos").list();

			Iterator it = allproducts.iterator();
			while (it.hasNext()) {
// for (Iterator iterator = allproducts.iterator(); iterator.hasNext();){
				Productos p = (Productos) it.next();
				System.out.print("Id: " + p.getId() + " ");
				System.out.print("Nombre: " + p.getNombre() + " ");
				System.out.println("Precio: " + p.getPrecio());
			}
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
	}

	@SuppressWarnings("deprecation")
	public Productos findProductById(int id) {
		Session session = sf.openSession();
		Transaction tx = null;
		Productos p = new Productos();
		try {
			System.out.println("loading the object from the database");
			tx = session.beginTransaction();
			p = (Productos) session.load(Productos.class, id);
			tx.commit();
			System.out.println("The product with id= " + id + " is: " + p.getNombre());
		} catch (ObjectNotFoundException e) {
			if (tx != null) {
				System.out.println(e);
				System.out.println("Product not found");
			}
		} catch (Exception e) {
			if (tx != null) {
				System.out.println(e);
				tx.rollback();
			}
		}

		finally {
			session.close();
		}
		return p;
	}

	
	public void deleteProductById(int id) {
		Productos p = new Productos();
		Session session = sf.openSession();
		Transaction tx = null;
		try {
			tx = session.beginTransaction();
			p = (Productos) session.load(Productos.class, id);
			session.delete(p);
			tx.commit();
			System.out.printf("Object deleted FROM THE DATABASE: %s, %s, %s\n", p.getId(), p.getNombre(),
					p.getPrecio());

		} catch (Exception e) {
			if (tx != null) {
				tx.rollback();
			}
		} finally {
			session.close();
		}
	}

	@SuppressWarnings({ "deprecation", "deprecation" })
	public void updateProductById(int id, String newName, double newPrice) {

		Productos p = new Productos();
		Session session = sf.openSession();
		Transaction tx = null;
		try {
			tx = session.beginTransaction();
			System.out.println("Updating a value");
			System.out.println("Before updating, we need to load the object");

			p = (Productos) session.load(Productos.class, id);// we load the pendrive

			p.setPrecio(newPrice);// we change the properties
			p.setNombre(newName);
			session.update(p);// we update the values in the database
			tx.commit();
			System.out.println("Object updated");
		} catch (Exception e) {
			System.out.println(e);
			if (tx != null) {
				tx.rollback();
			}
		} finally {
			session.close();
		}
	}

}
